﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Source;
using $safeprojectname$.Source.Classes;
using $safeprojectname$.Source.Scenes;
using SFML.Graphics;

namespace $safeprojectname$
{
    internal class Game : Engine
    {
        public Game() : base(800, 800, "Engine Test", Color.Black) { }

        

        public override void OnLoad()
        {
            Demo_Scene level1 = new Demo_Scene("level1");
            Win level2 = new Win("Win");
            LevelManager.ChangeLevel("level1");
            
        }

        public override void OnUpdate()
        {

            base.OnUpdate();
        }
    }
}
