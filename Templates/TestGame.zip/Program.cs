﻿namespace $safeprojectname$
{
    static class Program
    {
        static void Main(string[] args)
        {
            Game test = new Game();
        }
    }
}